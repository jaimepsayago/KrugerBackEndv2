package com.kruger.mvc.service;

public interface IServicio {
	public String operacion();

}
