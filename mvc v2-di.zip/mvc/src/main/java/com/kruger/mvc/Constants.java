package com.kruger.mvc;

public class Constants {
	public static final int NOT_FOUND=-1000;

}
